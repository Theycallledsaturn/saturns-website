document.addEventListener('DOMContentLoaded', () => {
  const bootScreen = document.getElementById('bootScreen');
  const mainDesktop = document.getElementById('mainDesktop');
  const startOSBtn = document.getElementById('startOS');
  const startBtn = document.querySelector('.start-btn');
  const startMenu = document.getElementById('startMenu');
  const desktop = document.querySelector('.desktop');
  const contextMenu = document.getElementById('contextMenu');
  const icons = document.querySelectorAll('.desktop-icon');

  // Boot sequence
  setTimeout(() => {
    startOSBtn.style.display = 'block';
  }, 3500);

  startOSBtn.addEventListener('click', () => {
    bootScreen.style.transition = 'opacity 1s';
    bootScreen.style.opacity = '0';
    setTimeout(() => {
      bootScreen.style.display = 'none';
      mainDesktop.style.display = 'block';
      // Fade in desktop
      mainDesktop.style.opacity = '0';
      setTimeout(() => {
        mainDesktop.style.transition = 'opacity 1s';
        mainDesktop.style.opacity = '1';
      }, 100);
    }, 1000);
  });

  // Clock
  function updateClock() {
    const now = new Date();
    const timeString = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    document.getElementById('clock').textContent = timeString;
  }
  setInterval(updateClock, 1000);
  updateClock();

  // Start Menu Toggle
  startBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    startMenu.style.display = startMenu.style.display === 'block' ? 'none' : 'block';
  });

  // Hide menus when clicking outside
  document.addEventListener('click', () => {
    startMenu.style.display = 'none';
    contextMenu.style.display = 'none';
  });

  // Enhanced icon hover effect
  icons.forEach(icon => {
    icon.addEventListener('mouseenter', () => {
      icon.style.transform = 'scale(1.05)';
      icon.style.transition = 'all 0.2s ease';
    });

    icon.addEventListener('mouseleave', () => {
      icon.style.transform = 'scale(1)';
    });
  });

  // Enhanced start button effect
  startBtn.addEventListener('mouseenter', () => {
    startBtn.style.transform = 'translateY(-1px)';
    startBtn.style.boxShadow = '0 4px 8px rgba(0,0,0,0.3)';
  });

  startBtn.addEventListener('mouseleave', () => {
    startBtn.style.transform = 'translateY(0)';
    startBtn.style.boxShadow = '0 2px 5px rgba(0,0,0,0.2)';
  });

  // Add smooth transitions for menu items
  const menuItems = document.querySelectorAll('.menu-item');
  menuItems.forEach(item => {
    item.addEventListener('mouseenter', () => {
      item.style.paddingLeft = '25px';
      item.style.transition = 'all 0.2s ease';
    });

    item.addEventListener('mouseleave', () => {
      item.style.paddingLeft = '20px';
    });
  });

  // Update icon handling for buttons
  const iconButtons = document.querySelectorAll('.desktop-icon');

  iconButtons.forEach(button => {
    button.addEventListener('click', (e) => {
      e.stopPropagation();
      iconButtons.forEach(b => b.classList.remove('selected'));
      button.classList.add('selected');
    });

    button.addEventListener('dblclick', () => {
      const appName = button.dataset.name;
      switch(appName) {
        case 'My Portfolio':
          window.open('https://sites.google.com/view/saturngfx/home', '_blank'); // Opens your portfolio
          break;
        case 'Price List':
          window.open('https://www.instagram.com/gatesofsaturn/', '_blank'); // Opens your Instagram price list
          break;
        case 'Socials':
          window.open('https://linktr.ee/saturn.jpg?utm_source=linktree_profile_share&ltsid=60aa3638-3246-4a61-9fc3-62bbb6654ab3', '_blank'); // Opens your social media links
          break;
        case 'Trash Can':
          alert('Opening Trash Can...'); // Placeholder action for Trash Can
          break;
        default:
          alert('App not found');
      }
    });

    // Add keyboard navigation
    button.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        button.dispatchEvent(new Event('dblclick'));
      }
    });
  });

  // Context menu
  desktop.addEventListener('contextmenu', (e) => {
    e.preventDefault();
    contextMenu.style.display = 'block';
    contextMenu.style.left = `${e.clientX}px`;
    contextMenu.style.top = `${e.clientY}px`;
  });

  // Drag and drop icons
  let draggedIcon = null;
  let offsetX, offsetY;

  icons.forEach(icon => {
    icon.addEventListener('mousedown', (e) => {
      if (e.button === 0) { // Left click only
        draggedIcon = icon;
        offsetX = e.clientX - icon.offsetLeft;
        offsetY = e.clientY - icon.offsetTop;
        icon.style.position = 'absolute';
        icon.style.zIndex = '1000';
      }
    });
  });

  document.addEventListener('mousemove', (e) => {
    if (draggedIcon) {
      draggedIcon.style.left = `${e.clientX - offsetX}px`;
      draggedIcon.style.top = `${e.clientY - offsetY}px`;
    }
  });

  document.addEventListener('mouseup', () => {
    if (draggedIcon) {
      draggedIcon.style.zIndex = '';
      draggedIcon = null;
    }
  });
});